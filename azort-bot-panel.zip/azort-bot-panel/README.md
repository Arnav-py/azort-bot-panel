# Azort Control Panel

A lightweight client dashboard + admin panel for restarting/stopping bots
hosted on Orihost (Pterodactyl), built for a small client base (10-20 users)
without a database or always-on server.

## What's in here

```
/                     client-facing static pages (root = clean URLs)
  index.html            → login
  dashboard.html         → bot list + restart/stop + detail drawer
  assets/css/style.css  → shared design system (client + devs)
  assets/js/app.js      → client dashboard logic

/devs                 admin-only static pages
  index.html            → devs login
  dashboard.html        → client management table + add/edit modal
  assets/js/devs.js    → admin logic

/api                  serverless functions (Vercel convention)
  login.js / logout.js           → client auth
  get-bots.js                    → returns only the logged-in user's bot(s)
  bot-action.js                  → restart/stop, with authorization + cooldown
  devs-login.js / devs-logout.js → admin auth
  devs-clients.js                → admin CRUD (list/add/edit/reset password)
  admin-tools.js                 → admin operations, bulk tools, announcements, audit, maintenance
  announcements.js               → authenticated client announcements + dismissal

/lib
  store.js         → JSON storage, password hashing, signed sessions, cooldowns
  pterodactyl.js   → the ONLY file that talks to the Pterodactyl Client API

/data
  users.json    → client accounts (username + password hash)
  bots.json     → user → server ID mapping (the authorization boundary)
  admins.json   → your own devs login
  announcements.json → global client announcements
  admin-settings.json → maintenance mode and message
  audit-log.json → admin activity history

/scripts
  set-password.js    → Set an account password without handling hashes
  hash-passwords.js  → CLI to generate a password hash when needed
```

## Setup

1. **Install the Vercel CLI** if you don't have it: `npm i -g vercel`
2. **Copy env vars**: `cp .env.example .env` and fill in:
   - `SESSION_SECRET` — any long random string (`openssl rand -hex 32`)
   - `PTERODACTYL_BASE_URL` — your Orihost panel URL
   - `PTERODACTYL_API_KEY` — your master Pterodactyl **Client API** key
   - `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN` (or Vercel's
     `KV_REST_API_URL` and `KV_REST_API_TOKEN`) — create a free Upstash Redis
     database and copy its REST credentials. These are required for admin
     edits to persist on Vercel.
3. **Set your own admin login.** Use your normal password; the helper hashes it automatically:
   ```
  node scripts/set-password.js admins arnav "yourRealPassword"
   ```
  Replace `arnav` with the username in `data/admins.json`. Log in at `/devs`
  using that username and the normal password you supplied.
4. **Delete the demo client** in `data/users.json` and `data/bots.json` (or
   just add real clients through the `/devs` panel once it's running — it
   generates the user + a temp password for you).
5. **Run locally**: `vercel dev`
6. **Deploy**: push this repo to GitHub, then `vercel --prod` or import the
   repo in the Vercel dashboard. Set the same env vars there under
   Project Settings → Environment Variables.

On the first deployment with Upstash configured, copy the contents of
`data/admins.json`, `data/users.json`, `data/bots.json`, `data/announcements.json`,
`data/admin-settings.json`, and `data/audit-log.json` into the matching Redis
keys with the `azort:` prefix.
The application reads those keys in production and uses local JSON files only
when the Redis variables are absent.

### Changing a password

Use the same command for an existing admin or client account:

```
node scripts/set-password.js admins arnav "newPassword"
node scripts/set-password.js users clientUsername "newPassword"
```

Passwords are entered normally, but only a one-way hash is saved in the data
files. Never replace `passwordHash` with a plaintext password.

## Important: persistent storage on Vercel

Vercel's serverless functions have a **read-only filesystem** at runtime
(except `/tmp`, which doesn't persist between requests). The JSON
read/write helpers in `lib/store.js` work as-is for local dev (`vercel dev`)
and clearly show the data shape, but for a real production deployment you
have two straightforward options — both are called out with comments right
in `lib/store.js`:

- **Swap in a small persistent store**: Vercel KV, Upstash Redis, or Turso
  (hosted SQLite) all have free tiers big enough for 10-20 users. You'd only
  need to change what's inside `readJSON`/`writeJSON` — every API route stays
  the same.
- **Host on an always-on Node process instead** (a small VPS, Railway,
  Fly.io) — then the filesystem persists normally and nothing changes.

## Where the security boundaries live

- **Authentication**: `login.js` / `devs-login.js` check a hashed password
  and issue a signed, HttpOnly session cookie. The password itself is never
  stored or shown in plaintext anywhere — including in the devs panel. "Reset
  password" generates a new temp password rather than revealing the old one.
- **Authorization (the important one)**: `get-bots.js` and `bot-action.js`
  both look up the bot by the **session's** `userId` server-side — never by
  a value the browser sends. Even if someone edits the `botId` in devtools
  or replays a request with a different ID, the ownership check in
  `bot-action.js` rejects it with a 403 unless that bot actually belongs to
  their session.
- **Rate limiting**: `bot-action.js` enforces a 60-second cooldown per
  user+bot before another power signal is allowed, so a laggy bot doesn't
  turn into a spam-click storm against Orihost's own API.
- **Secrets**: `PTERODACTYL_API_KEY` only ever exists inside
  `lib/pterodactyl.js`, read from an environment variable. It's never sent
  to the browser, logged, or committed to the repo.

## Customizing

- Colors, type, and the pulse-ring status indicator all live in
  `assets/css/style.css` as CSS variables at the top — safe to retheme
  without touching layout.
- The watermark (`Azort Development | Built by Arnav`) is a fixed-position
  element on every page — edit the text directly in each HTML file if you
  ever want to change it.
