/* Azort Control Panel — single server detail page (/servers/:id) */

let pageBot = null;
let pageMaintenance = false;

function serverIdFromPath() {
  const parts = window.location.pathname.split('/').filter(Boolean);
  // supports /servers/<id> (clean URL) and /server.html?id=<id> (fallback)
  const idx = parts.indexOf('servers');
  if (idx !== -1 && parts[idx + 1]) return decodeURIComponent(parts[idx + 1]);
  const params = new URLSearchParams(window.location.search);
  return params.get('id');
}

function renderServerPage(bot, user, maintenance) {
  pageBot = bot;
  pageMaintenance = Boolean(maintenance?.maintenanceMode);

  document.getElementById('userName').textContent = user?.displayName || user?.username || '—';
  document.getElementById('userInitial').textContent = (user?.displayName || user?.username || '?')[0].toUpperCase();

  const details = bot.details || {};
  const status = bot.status;

  document.getElementById('content').innerHTML = `
    ${pageMaintenance ? `<div class="maintenance-banner">Server controls are temporarily disabled during maintenance.</div>` : ''}
    <div class="server-hero">
      <div>
        <span class="section-label">Server workspace</span>
        <h1>${bot.name}</h1>
        <div class="status-row" style="justify-content:flex-start">
          <div class="pulse ${status === 'online' ? '' : status === 'restarting' ? 'restarting' : 'offline'}" id="pagePulse">
            <div class="pulse-ring"></div><div class="pulse-ring"></div><div class="pulse-dot"></div>
          </div>
          <span class="status-text ${status}" id="pageStatusText">${statusLabel(status)}</span>
        </div>
        <p class="page-sub" style="margin-top:14px;max-width:560px">${details.description || 'No server description available.'}</p>
      </div>
      <div class="btn-row" style="margin-top:0">
        <button class="btn btn-primary" id="startBtn" ${pageMaintenance || status === 'online' ? 'disabled' : ''}>Start</button>
        <button class="btn btn-primary" id="restartBtn" ${pageMaintenance ? 'disabled' : ''}>Restart</button>
        <button class="btn-ghost" id="stopBtn" ${pageMaintenance || status === 'offline' ? 'disabled' : ''}>Stop</button>
      </div>
    </div>
    <p class="form-note" id="cooldownNote"></p>

    <section class="detail-section">
      <h2>Server info</h2>
      <div class="billing-grid">
        <div class="info-item"><span class="section-label">Server ID</span><strong class="mono">${bot.serverId}</strong></div>
        <div class="info-item"><span class="section-label">Node</span><strong>${details.node || '—'}</strong></div>
        <div class="info-item"><span class="section-label">Allocation</span><strong>${details.allocation || '—'}</strong></div>
        <div class="info-item"><span class="section-label">Plan</span><strong>${bot.plan || 'Standard'}</strong></div>
        <div class="info-item"><span class="section-label">Uptime</span><strong>${fmtUptime(details.uptime)}</strong></div>
        <div class="info-item"><span class="section-label">Last action</span><strong>${bot.lastAction || 'None yet'}</strong></div>
      </div>
    </section>

    <section class="detail-section">
      <h2>Billing &amp; status</h2>
      <div class="billing-grid">
        <div class="info-item"><span class="section-label">Access status</span><strong>${bot.status === 'suspended' ? 'Suspended' : 'Active'}</strong></div>
        <div class="info-item"><span class="section-label">Expires</span><strong>${fmtDate(bot.expiresAt)}</strong></div>
        <div class="info-item"><span class="section-label">Plan</span><strong>${bot.plan || 'Standard'}</strong></div>
      </div>
    </section>

    <section class="detail-section">
      <h2>Resource usage</h2>
      <div class="billing-grid">
        <div class="info-item"><span class="section-label">CPU</span><strong>${details.cpuUsed ? `${details.cpuUsed.toFixed(1)}%` : '—'}</strong><span class="form-note" style="margin-top:4px">${details.cpuLimit ? `${details.cpuLimit}% limit` : `${bot.cpuLimit || '—'}% limit`}</span></div>
        <div class="info-item"><span class="section-label">Memory</span><strong>${details.memoryUsed ? fmtBytes(details.memoryUsed) : '—'}</strong><span class="form-note" style="margin-top:4px">${details.memoryLimit ? `${fmtBytes(details.memoryLimit * 1024 * 1024)} limit` : `${bot.memLimit || '—'} MB limit`}</span></div>
        <div class="info-item"><span class="section-label">Disk</span><strong>${details.diskUsed ? fmtBytes(details.diskUsed) : '—'}</strong><span class="form-note" style="margin-top:4px">${details.diskLimit ? `${fmtBytes(details.diskLimit * 1024 * 1024)} limit` : '—'}</span></div>
      </div>
    </section>
  `;

  document.getElementById('startBtn').addEventListener('click', () => pageAction('start'));
  document.getElementById('restartBtn').addEventListener('click', () => pageAction('restart'));
  document.getElementById('stopBtn').addEventListener('click', () => pageAction('stop'));
}

async function pageAction(action) {
  if (!pageBot) return;
  const buttons = ['startBtn', 'restartBtn', 'stopBtn'].map(id => document.getElementById(id)).filter(Boolean);
  buttons.forEach(b => { b.disabled = true; });

  try {
    const res = await fetch('/api/bot-action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ botId: pageBot.id, action })
    });
    const data = await res.json();

    if (res.status === 429) {
      document.getElementById('cooldownNote').textContent = `Please wait ${data.retryAfter || 'a moment'} before trying again.`;
      showToast('Action on cooldown', 'err');
    } else if (!res.ok) {
      showToast(data.error || 'Action failed', 'err');
    } else {
      showToast(`${action[0].toUpperCase() + action.slice(1)} signal sent`, 'ok');
      loadServerPage();
    }
  } catch (e) {
    showToast('Network error — try again', 'err');
  } finally {
    buttons.forEach(b => { b.disabled = false; });
  }
}

async function loadServerPage() {
  const serverId = serverIdFromPath();
  const content = document.getElementById('content');
  if (!serverId) {
    content.innerHTML = `<div class="empty-state"><h3>No server specified</h3><p>Go back to your dashboard and pick a bot.</p></div>`;
    return;
  }

  try {
    const res = await fetch('/api/get-bots');
    if (res.status === 401) { window.location.href = '/index.html'; return; }
    const data = await res.json();
    const bot = (data.bots || []).find(b => b.serverId === serverId || b.id === serverId);
    if (!bot) {
      content.innerHTML = `<div class="empty-state"><h3>Server not found</h3><p>This server isn't assigned to your account.</p></div>`;
      return;
    }
    renderServerPage(bot, data.user, data.maintenance);
  } catch (e) {
    content.innerHTML = `<div class="empty-state"><h3>Couldn't load this server</h3><p>Refresh the page — if this keeps happening, contact Azort support.</p></div>`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadServerPage();
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/index.html';
  });
  setInterval(loadServerPage, 30000);
});
